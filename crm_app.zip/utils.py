import streamlit as st
import pandas as pd
import numpy as np
import base64
import json
import plotly.express as px
import plotly.graph_objects as go
from io import BytesIO

def create_download_link(fig, filename):
    """
    Create a download link for a Plotly figure
    """
    # Convert figure to HTML
    html_bytes = fig.to_html(full_html=False, include_plotlyjs='cdn')
    
    # Encode HTML to base64
    b64 = base64.b64encode(html_bytes.encode()).decode()
    
    # Create download link
    href = f'<a href="data:text/html;base64,{b64}" download="{filename}.html">Click to download {filename}.html</a>'
    st.markdown(href, unsafe_allow_html=True)
    
    # Also create an image download option
    img_bytes = fig.to_image(format="png", width=1200, height=800)
    img_b64 = base64.b64encode(img_bytes).decode()
    img_href = f'<a href="data:image/png;base64,{img_b64}" download="{filename}.png">Click to download {filename}.png</a>'
    st.markdown(img_href, unsafe_allow_html=True)

def get_data_summary(data):
    """
    Generate a basic summary of the DataFrame
    """
    summary = {
        "rows": len(data),
        "columns": len(data.columns),
        "column_types": data.dtypes.astype(str).to_dict(),
        "missing_values": data.isna().sum().to_dict(),
        "numeric_columns": list(data.select_dtypes(include=['number']).columns),
        "categorical_columns": list(data.select_dtypes(exclude=['number']).columns)
    }
    
    # Add numeric column statistics if there are numeric columns
    if summary["numeric_columns"]:
        summary["numeric_stats"] = data[summary["numeric_columns"]].describe().to_dict()
    
    return summary

def clean_data(data, options):
    """
    Apply basic data cleaning operations based on options
    """
    df = data.copy()
    
    if "drop_duplicates" in options and options["drop_duplicates"]:
        df = df.drop_duplicates()
    
    if "drop_na_rows" in options and options["drop_na_rows"]:
        df = df.dropna()
    
    if "fill_na" in options and options["fill_na"]:
        fill_value = options.get("fill_value", 0)
        fill_method = options.get("fill_method", "value")
        
        if fill_method == "value":
            df = df.fillna(fill_value)
        elif fill_method == "mean":
            for col in df.select_dtypes(include=['number']).columns:
                df[col] = df[col].fillna(df[col].mean())
        elif fill_method == "median":
            for col in df.select_dtypes(include=['number']).columns:
                df[col] = df[col].fillna(df[col].median())
        elif fill_method == "mode":
            for col in df.columns:
                df[col] = df[col].fillna(df[col].mode()[0] if not df[col].mode().empty else np.nan)
    
    return df

def export_data(data, format_type):
    """
    Export the DataFrame to various formats
    """
    if format_type == "csv":
        csv = data.to_csv(index=False)
        b64 = base64.b64encode(csv.encode()).decode()
        href = f'<a href="data:file/csv;base64,{b64}" download="data_export.csv">Download CSV File</a>'
        return href
    
    elif format_type == "excel":
        towrite = BytesIO()
        data.to_excel(towrite, index=False)
        towrite.seek(0)
        b64 = base64.b64encode(towrite.read()).decode()
        href = f'<a href="data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,{b64}" download="data_export.xlsx">Download Excel File</a>'
        return href
    
    elif format_type == "json":
        json_str = data.to_json(orient="records")
        b64 = base64.b64encode(json_str.encode()).decode()
        href = f'<a href="data:file/json;base64,{b64}" download="data_export.json">Download JSON File</a>'
        return href
    
    return None

def apply_filter(data, filters):
    """
    Apply filters to the DataFrame
    """
    df = data.copy()
    
    for filter_info in filters:
        column = filter_info.get("column")
        operator = filter_info.get("operator")
        value = filter_info.get("value")
        
        if not column or not operator:
            continue
        
        # Handle different operators
        if operator == "equals":
            df = df[df[column] == value]
        elif operator == "not_equals":
            df = df[df[column] != value]
        elif operator == "greater_than":
            df = df[df[column] > value]
        elif operator == "less_than":
            df = df[df[column] < value]
        elif operator == "contains":
            df = df[df[column].astype(str).str.contains(str(value), na=False)]
        elif operator == "starts_with":
            df = df[df[column].astype(str).str.startswith(str(value), na=False)]
        elif operator == "ends_with":
            df = df[df[column].astype(str).str.endswith(str(value), na=False)]
        elif operator == "in_range":
            if isinstance(value, list) and len(value) == 2:
                df = df[(df[column] >= value[0]) & (df[column] <= value[1])]
    
    return df
