import streamlit as st
import pandas as pd
import numpy as np
import os
import json
from openai import OpenAI
import plotly.express as px
import plotly.graph_objects as go
import uuid
from datetime import datetime

# Initialize OpenAI client
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")

def get_openai_client():
    """Initialize and return OpenAI client with API key"""
    if not OPENAI_API_KEY:
        st.error("OpenAI API key is missing. Please set the OPENAI_API_KEY environment variable.")
        return None
    
    return OpenAI(api_key=OPENAI_API_KEY)

def generate_data_prompt(data, question):
    """Generate a prompt for the OpenAI API based on the data and question"""
    # Get data information
    df_info = {
        "columns": list(data.columns),
        "dtypes": {col: str(data[col].dtype) for col in data.columns},
        "sample_rows": data.head(5).to_dict(orient="records"),
        "shape": data.shape,
    }
    
    # Create a summary of numeric columns
    numeric_cols = data.select_dtypes(include=['number']).columns
    column_stats = {}
    if len(numeric_cols) > 0:
        for col in numeric_cols:
            column_stats[col] = {
                "min": float(data[col].min()),
                "max": float(data[col].max()),
                "mean": float(data[col].mean()),
                "median": float(data[col].median()),
                "null_count": int(data[col].isna().sum())
            }
    
    # Create a summary of categorical columns
    cat_cols = data.select_dtypes(exclude=['number']).columns
    cat_stats = {}
    if len(cat_cols) > 0:
        for col in cat_cols:
            cat_stats[col] = {
                "unique_values": int(data[col].nunique()),
                "top_values": data[col].value_counts().head(5).to_dict(),
                "null_count": int(data[col].isna().sum())
            }
    
    # Create the system prompt
    system_prompt = f"""You are a data analysis assistant. Your job is to help the user analyze and understand their data.
You have access to a pandas DataFrame with the following information:

DataFrame Shape: {df_info['shape'][0]} rows × {df_info['shape'][1]} columns

Column names and types:
{json.dumps({col: str(dtype) for col, dtype in df_info['dtypes'].items()}, indent=2)}

Here are some sample rows from the data:
{json.dumps(df_info['sample_rows'], indent=2)}

Numeric column statistics:
{json.dumps(column_stats, indent=2)}

Categorical column statistics:
{json.dumps(cat_stats, indent=2)}

Guidelines for your response:
1. Provide concise, accurate answers based on the data
2. If the user asks for a visualization, provide Python code using plotly express or plotly graph_objects
3. If the user asks for statistics or calculations, provide the exact values
4. If you can't answer from the available data, explain what's missing
5. Format code blocks with ``` for proper display
6. For visualizations, wrap the code in <visualization> tags so it can be executed

Example visualization code format:
<visualization>
import plotly.express as px
fig = px.bar(df, x="column_name", y="value_column")
fig
</visualization>
"""

    return system_prompt, question

def process_response(response, data):
    """Process the response from OpenAI to extract text and visualization code"""
    # Split the response into text and visualization parts
    response_text = response
    viz_code = None
    
    # Check if response contains visualization code
    if "<visualization>" in response and "</visualization>" in response:
        # Extract the visualization code
        viz_start = response.find("<visualization>") + len("<visualization>")
        viz_end = response.find("</visualization>")
        viz_code = response[viz_start:viz_end].strip()
        
        # Update the response text to remove the visualization code
        before_viz = response[:response.find("<visualization>")]
        after_viz = response[response.find("</visualization>") + len("</visualization>"):]
        response_text = before_viz + "Visualization is displayed below." + after_viz
    
    # Return the processed response
    return response_text, viz_code

def render_visualization(viz_code, data):
    """Render the visualization code"""
    if not viz_code:
        return None
    
    try:
        # Set up the environment for execution
        local_vars = {"df": data, "px": px, "go": go, "pd": pd, "np": np}
        
        # Execute the code
        exec(viz_code, globals(), local_vars)
        
        # The last variable should be the figure
        # Find the last assignment in the code
        lines = viz_code.strip().split('\n')
        last_var = None
        for line in reversed(lines):
            line = line.strip()
            if '=' in line and not line.startswith('#'):
                last_var = line.split('=')[0].strip()
                break
        
        # If no assignment found, look for the last variable name alone on a line
        if not last_var:
            for line in reversed(lines):
                line = line.strip()
                if line and not '=' in line and not line.startswith('#'):
                    last_var = line
                    break
        
        # If we found a variable, return it
        if last_var and last_var in local_vars:
            return local_vars[last_var]
        
        # Try to find any figure object in the local vars
        for var_name, var_value in local_vars.items():
            if isinstance(var_value, (px.Figure, go.Figure)):
                return var_value
        
        # If all else fails, try for "fig"
        if "fig" in local_vars:
            return local_vars["fig"]
        
        return None
    except Exception as e:
        st.error(f"Error rendering visualization: {e}")
        st.code(viz_code, language="python")
        return None

def chat_interface(data):
    """Create a chat interface for the chatbot"""
    st.subheader("Chat with Your Data")
    st.markdown("""
    Ask questions about your data in natural language. You can:
    - Request summary statistics
    - Ask for correlations between variables
    - Inquire about trends or patterns
    - Request specific visualizations
    - Ask for data insights or explanations
    """)
    
    # Initialize chat history
    if "chat_history" not in st.session_state:
        st.session_state.chat_history = []
    
    # Function to add a message to the chat history
    def add_message(role, content, viz=None, viz_id=None):
        st.session_state.chat_history.append({
            "role": role,
            "content": content,
            "timestamp": datetime.now().isoformat(),
            "visualization": viz,
            "viz_id": viz_id
        })
    
    # Display chat history
    for message in st.session_state.chat_history:
        if message["role"] == "user":
            st.markdown(f"**You:** {message['content']}")
        else:
            st.markdown(f"**Assistant:** {message['content']}")
            
            # If there's a visualization, display it
            if message.get("visualization"):
                try:
                    st.plotly_chart(message["visualization"], use_container_width=True)
                except Exception as e:
                    st.error(f"Error displaying visualization: {e}")
    
    # Input for new message
    with st.form("chat_form", clear_on_submit=True):
        user_input = st.text_area("Your question:", height=80)
        
        col1, col2 = st.columns([1, 5])
        with col1:
            submit_button = st.form_submit_button("Ask")
        with col2:
            if submit_button and not user_input.strip():
                st.error("Please enter a question.")
    
    # Process user input when submitted
    if submit_button and user_input.strip():
        # Add user message to chat history
        add_message("user", user_input)
        
        with st.spinner("Thinking..."):
            try:
                # Get OpenAI client
                client = get_openai_client()
                if not client:
                    st.error("Unable to connect to OpenAI API. Please check your API key.")
                    return
                
                # Generate prompt for OpenAI
                system_prompt, user_question = generate_data_prompt(data, user_input)
                
                # Call OpenAI API
                # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
                # do not change this unless explicitly requested by the user
                response = client.chat.completions.create(
                    model="gpt-4o",
                    messages=[
                        {"role": "system", "content": system_prompt},
                        {"role": "user", "content": user_question}
                    ],
                    max_tokens=2000,
                )
                
                # Extract the response content
                response_content = response.choices[0].message.content
                
                # Process response to extract text and visualization code
                response_text, viz_code = process_response(response_content, data)
                
                # Render visualization if present
                viz = None
                viz_id = None
                if viz_code:
                    viz = render_visualization(viz_code, data)
                    viz_id = str(uuid.uuid4())
                
                # Add assistant message to chat history
                add_message("assistant", response_text, viz, viz_id)
                
                # Save visualization to visualizations if present
                if viz and viz_id:
                    # Create a title for the visualization
                    viz_title = f"Chat Visualization - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
                    
                    # Save to session state
                    viz_config = {
                        "id": viz_id,
                        "name": viz_title,
                        "type": "Chat Generated",
                        "created_at": datetime.now().isoformat(),
                        "fig_json": viz.to_json(),
                        "config": {
                            "chart_type": "Chat Generated",
                            "parameters": {}
                        }
                    }
                    
                    if 'visualizations' not in st.session_state:
                        st.session_state.visualizations = []
                    
                    st.session_state.visualizations.append(viz_config)
                
                # Rerun the app to show the new messages
                st.rerun()
                
            except Exception as e:
                st.error(f"Error processing your question: {str(e)}")
                # Add error message to chat history
                add_message("assistant", f"I'm sorry, I encountered an error: {str(e)}")
