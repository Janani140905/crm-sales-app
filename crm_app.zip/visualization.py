import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import json
from datetime import datetime
import uuid
import utils

def create_visualization(data):
    """
    Interface for creating new visualizations
    """
    st.subheader("Create New Visualization")
    
    # Chart type selection
    chart_type = st.selectbox(
        "Select Chart Type",
        ["Bar Chart", "Line Chart", "Scatter Plot", "Pie Chart", "Histogram", "Box Plot", "Heatmap"]
    )
    
    # Basic information
    viz_name = st.text_input("Visualization Name", f"New {chart_type} - {datetime.now().strftime('%Y-%m-%d')}")
    
    # Get column types for better selection options
    numeric_cols = data.select_dtypes(include=['number']).columns.tolist()
    categorical_cols = data.select_dtypes(exclude=['number']).columns.tolist()
    all_cols = data.columns.tolist()
    
    # Common parameters
    with st.expander("Chart Parameters", expanded=True):
        # Parameters based on chart type
        if chart_type == "Bar Chart":
            x_axis = st.selectbox("X-axis (Categories)", categorical_cols if categorical_cols else all_cols)
            y_axis = st.selectbox("Y-axis (Values)", numeric_cols if numeric_cols else all_cols)
            orientation = st.radio("Orientation", ["Vertical", "Horizontal"])
            color_by = st.selectbox("Color by (optional)", ["None"] + categorical_cols)
            agg_func = st.selectbox("Aggregation Function", ["sum", "mean", "count", "median", "min", "max"])
            
            # Generate chart
            fig = generate_bar_chart(data, x_axis, y_axis, orientation, color_by, agg_func)
            
        elif chart_type == "Line Chart":
            x_axis = st.selectbox("X-axis", all_cols)
            y_axis = st.selectbox("Y-axis", numeric_cols if numeric_cols else all_cols, index=min(1, len(numeric_cols)-1) if len(numeric_cols) > 1 else 0)
            color_by = st.selectbox("Color by (Group)", ["None"] + categorical_cols)
            markers = st.checkbox("Show Markers", value=True)
            
            # Generate chart
            fig = generate_line_chart(data, x_axis, y_axis, color_by, markers)
            
        elif chart_type == "Scatter Plot":
            x_axis = st.selectbox("X-axis", numeric_cols if numeric_cols else all_cols)
            y_axis = st.selectbox("Y-axis", numeric_cols if numeric_cols else all_cols, index=min(1, len(numeric_cols)-1) if len(numeric_cols) > 1 else 0)
            color_by = st.selectbox("Color by", ["None"] + categorical_cols + numeric_cols)
            size_by = st.selectbox("Size by", ["None"] + numeric_cols)
            show_trendline = st.checkbox("Show Trendline", value=False)
            
            # Generate chart
            fig = generate_scatter_plot(data, x_axis, y_axis, color_by, size_by, show_trendline)
            
        elif chart_type == "Pie Chart":
            names = st.selectbox("Categories", categorical_cols if categorical_cols else all_cols)
            values = st.selectbox("Values", numeric_cols if numeric_cols else all_cols)
            hole = st.slider("Donut Hole Size", 0.0, 0.8, 0.0, 0.1)
            
            # Generate chart
            fig = generate_pie_chart(data, names, values, hole)
            
        elif chart_type == "Histogram":
            column = st.selectbox("Column", numeric_cols if numeric_cols else all_cols)
            bins = st.slider("Number of Bins", 5, 100, 30)
            color_by = st.selectbox("Color by", ["None"] + categorical_cols)
            
            # Generate chart
            fig = generate_histogram(data, column, bins, color_by)
            
        elif chart_type == "Box Plot":
            y_axis = st.selectbox("Value Column", numeric_cols if numeric_cols else all_cols)
            x_axis = st.selectbox("Category Column (optional)", ["None"] + categorical_cols)
            color = st.selectbox("Color by", ["None"] + categorical_cols)
            
            # Generate chart
            fig = generate_box_plot(data, y_axis, x_axis, color)
            
        elif chart_type == "Heatmap":
            if len(numeric_cols) < 2:
                st.warning("Need at least 2 numeric columns for a correlation heatmap.")
                fig = go.Figure()
            else:
                columns = st.multiselect("Select Columns for Correlation", numeric_cols, default=numeric_cols[:min(5, len(numeric_cols))])
                
                if not columns or len(columns) < 2:
                    st.warning("Please select at least 2 columns.")
                    fig = go.Figure()
                else:
                    # Generate chart
                    fig = generate_heatmap(data, columns)
    
    # Layout customization
    with st.expander("Layout Customization"):
        title = st.text_input("Chart Title", viz_name)
        x_title = st.text_input("X-axis Title", "")
        y_title = st.text_input("Y-axis Title", "")
        legend_title = st.text_input("Legend Title", "")
        width = st.slider("Width", 400, 1200, 800)
        height = st.slider("Height", 300, 1000, 500)
        
        # Update layout
        fig.update_layout(
            title=title,
            xaxis_title=x_title if x_title else None,
            yaxis_title=y_title if y_title else None,
            legend_title=legend_title if legend_title else None,
            width=width,
            height=height
        )
    
    # Display the visualization
    st.plotly_chart(fig, use_container_width=True)
    
    # Save visualization
    col1, col2 = st.columns([1, 3])
    with col1:
        save_button = st.button("Save Visualization")
    
    with col2:
        if save_button:
            # Create unique ID for the visualization
            viz_id = str(uuid.uuid4())
            
            # Save the visualization configuration and fig to session state
            viz_config = {
                "id": viz_id,
                "name": viz_name,
                "type": chart_type,
                "created_at": datetime.now().isoformat(),
                "fig_json": fig.to_json(),
                "config": {
                    "chart_type": chart_type,
                    "parameters": {key: value for key, value in st.session_state.items() if key.startswith(f"_{chart_type.lower().replace(' ', '_')}")}
                }
            }
            
            if 'visualizations' not in st.session_state:
                st.session_state.visualizations = []
                
            st.session_state.visualizations.append(viz_config)
            st.success(f"Visualization '{viz_name}' saved successfully!")

def view_saved_visualizations():
    """
    View and manage saved visualizations
    """
    st.subheader("Saved Visualizations")
    
    if not st.session_state.visualizations:
        st.info("No visualizations saved yet. Create a visualization first.")
        return
    
    # Display saved visualizations
    for i, viz in enumerate(st.session_state.visualizations):
        with st.expander(f"{i+1}. {viz['name']} ({viz['type']})", expanded=i==0):
            # Load the figure from JSON
            fig_dict = json.loads(viz['fig_json'])
            fig = go.Figure(fig_dict)
            
            # Display the visualization
            st.plotly_chart(fig, use_container_width=True)
            
            # Buttons for actions
            col1, col2, col3 = st.columns(3)
            
            with col1:
                if st.button(f"Delete", key=f"delete_{viz['id']}"):
                    st.session_state.visualizations.pop(i)
                    st.rerun()
            
            with col2:
                if st.button(f"Share", key=f"share_{viz['id']}"):
                    # Create a shareable link
                    share_id = str(uuid.uuid4())
                    if 'shared_visualizations' not in st.session_state:
                        st.session_state.shared_visualizations = {}
                    
                    st.session_state.shared_visualizations[share_id] = {
                        "viz_id": viz['id'],
                        "name": viz['name'],
                        "type": viz['type'],
                        "created_at": datetime.now().isoformat(),
                        "created_by": st.session_state.current_session_id,
                        "fig_json": viz['fig_json']
                    }
                    
                    share_url = f"?share_id={share_id}"
                    st.session_state.last_shared_id = share_id
                    st.success("Visualization shared! Copy the link below:")
                    st.code(share_url)
            
            with col3:
                if st.button(f"Download", key=f"download_{viz['id']}"):
                    # Create a download link
                    utils.create_download_link(fig, viz['name'])

def shared_visualizations():
    """
    View shared visualizations
    """
    # Check if the URL contains a share_id parameter
    query_params = st.experimental_get_query_params()
    if "share_id" in query_params:
        share_id = query_params["share_id"][0]
        
        if 'shared_visualizations' in st.session_state and share_id in st.session_state.shared_visualizations:
            shared_viz = st.session_state.shared_visualizations[share_id]
            
            st.subheader(f"Shared Visualization: {shared_viz['name']}")
            
            # Display information about the shared visualization
            st.write(f"Type: {shared_viz['type']}")
            st.write(f"Shared on: {datetime.fromisoformat(shared_viz['created_at']).strftime('%Y-%m-%d %H:%M')}")
            
            # Load and display the figure
            fig_dict = json.loads(shared_viz['fig_json'])
            fig = go.Figure(fig_dict)
            st.plotly_chart(fig, use_container_width=True)
            
            # Option to download
            if st.button("Download Visualization"):
                utils.create_download_link(fig, shared_viz['name'])
        else:
            st.warning("The shared visualization could not be found. It may have expired or been deleted.")
    else:
        if 'shared_visualizations' in st.session_state and st.session_state.shared_visualizations:
            st.subheader("Your Shared Visualizations")
            
            for share_id, viz in st.session_state.shared_visualizations.items():
                if viz['created_by'] == st.session_state.current_session_id:
                    with st.expander(f"{viz['name']} ({viz['type']})"):
                        st.write(f"Shared on: {datetime.fromisoformat(viz['created_at']).strftime('%Y-%m-%d %H:%M')}")
                        
                        # Create shareable link
                        share_url = f"?share_id={share_id}"
                        st.code(share_url)
                        
                        # Load and display the figure
                        fig_dict = json.loads(viz['fig_json'])
                        fig = go.Figure(fig_dict)
                        st.plotly_chart(fig, use_container_width=True)
                        
                        if st.button(f"Delete Share", key=f"delete_share_{share_id}"):
                            del st.session_state.shared_visualizations[share_id]
                            st.rerun()
        else:
            st.info("You haven't shared any visualizations yet.")

# Chart generation functions
def generate_bar_chart(data, x_axis, y_axis, orientation, color_by, agg_func):
    """Generate a bar chart"""
    if orientation == "Vertical":
        if color_by != "None":
            fig = px.bar(
                data,
                x=x_axis,
                y=y_axis,
                color=color_by,
                barmode='group',
                title=f"{y_axis} by {x_axis}",
                labels={x_axis: x_axis, y_axis: y_axis}
            )
        else:
            # Aggregate data if needed
            if agg_func != "count":
                agg_data = data.groupby(x_axis)[y_axis].agg(agg_func).reset_index()
                fig = px.bar(
                    agg_data,
                    x=x_axis,
                    y=y_axis,
                    title=f"{agg_func.capitalize()} of {y_axis} by {x_axis}",
                    labels={x_axis: x_axis, y_axis: f"{agg_func.capitalize()} of {y_axis}"}
                )
            else:
                count_data = data.groupby(x_axis).size().reset_index(name='count')
                fig = px.bar(
                    count_data,
                    x=x_axis,
                    y='count',
                    title=f"Count by {x_axis}",
                    labels={x_axis: x_axis, 'count': 'Count'}
                )
    else:  # Horizontal
        if color_by != "None":
            fig = px.bar(
                data,
                y=x_axis,
                x=y_axis,
                color=color_by,
                barmode='group',
                orientation='h',
                title=f"{y_axis} by {x_axis}",
                labels={x_axis: x_axis, y_axis: y_axis}
            )
        else:
            # Aggregate data if needed
            if agg_func != "count":
                agg_data = data.groupby(x_axis)[y_axis].agg(agg_func).reset_index()
                fig = px.bar(
                    agg_data,
                    y=x_axis,
                    x=y_axis,
                    orientation='h',
                    title=f"{agg_func.capitalize()} of {y_axis} by {x_axis}",
                    labels={x_axis: x_axis, y_axis: f"{agg_func.capitalize()} of {y_axis}"}
                )
            else:
                count_data = data.groupby(x_axis).size().reset_index(name='count')
                fig = px.bar(
                    count_data,
                    y=x_axis,
                    x='count',
                    orientation='h',
                    title=f"Count by {x_axis}",
                    labels={x_axis: x_axis, 'count': 'Count'}
                )
    
    return fig

def generate_line_chart(data, x_axis, y_axis, color_by, markers):
    """Generate a line chart"""
    if color_by != "None":
        fig = px.line(
            data,
            x=x_axis,
            y=y_axis,
            color=color_by,
            markers=markers,
            title=f"{y_axis} over {x_axis}",
            labels={x_axis: x_axis, y_axis: y_axis}
        )
    else:
        fig = px.line(
            data,
            x=x_axis,
            y=y_axis,
            markers=markers,
            title=f"{y_axis} over {x_axis}",
            labels={x_axis: x_axis, y_axis: y_axis}
        )
    
    return fig

def generate_scatter_plot(data, x_axis, y_axis, color_by, size_by, show_trendline):
    """Generate a scatter plot"""
    trendline = "ols" if show_trendline else None
    
    if color_by != "None" and size_by != "None":
        fig = px.scatter(
            data,
            x=x_axis,
            y=y_axis,
            color=color_by,
            size=size_by,
            trendline=trendline,
            title=f"{y_axis} vs {x_axis}",
            labels={x_axis: x_axis, y_axis: y_axis}
        )
    elif color_by != "None":
        fig = px.scatter(
            data,
            x=x_axis,
            y=y_axis,
            color=color_by,
            trendline=trendline,
            title=f"{y_axis} vs {x_axis}",
            labels={x_axis: x_axis, y_axis: y_axis}
        )
    elif size_by != "None":
        fig = px.scatter(
            data,
            x=x_axis,
            y=y_axis,
            size=size_by,
            trendline=trendline,
            title=f"{y_axis} vs {x_axis}",
            labels={x_axis: x_axis, y_axis: y_axis}
        )
    else:
        fig = px.scatter(
            data,
            x=x_axis,
            y=y_axis,
            trendline=trendline,
            title=f"{y_axis} vs {x_axis}",
            labels={x_axis: x_axis, y_axis: y_axis}
        )
    
    return fig

def generate_pie_chart(data, names, values, hole):
    """Generate a pie chart"""
    # Group data for the pie chart
    pie_data = data.groupby(names)[values].sum().reset_index()
    
    fig = px.pie(
        pie_data,
        names=names,
        values=values,
        hole=hole,
        title=f"{values} by {names}"
    )
    
    return fig

def generate_histogram(data, column, bins, color_by):
    """Generate a histogram"""
    if color_by != "None":
        fig = px.histogram(
            data,
            x=column,
            color=color_by,
            nbins=bins,
            title=f"Histogram of {column}",
            labels={column: column}
        )
    else:
        fig = px.histogram(
            data,
            x=column,
            nbins=bins,
            title=f"Histogram of {column}",
            labels={column: column}
        )
    
    return fig

def generate_box_plot(data, y_axis, x_axis, color):
    """Generate a box plot"""
    if x_axis != "None" and color != "None":
        fig = px.box(
            data,
            y=y_axis,
            x=x_axis,
            color=color,
            title=f"Box Plot of {y_axis} by {x_axis}",
            labels={y_axis: y_axis, x_axis: x_axis}
        )
    elif x_axis != "None":
        fig = px.box(
            data,
            y=y_axis,
            x=x_axis,
            title=f"Box Plot of {y_axis} by {x_axis}",
            labels={y_axis: y_axis, x_axis: x_axis}
        )
    elif color != "None":
        fig = px.box(
            data,
            y=y_axis,
            color=color,
            title=f"Box Plot of {y_axis}",
            labels={y_axis: y_axis}
        )
    else:
        fig = px.box(
            data,
            y=y_axis,
            title=f"Box Plot of {y_axis}",
            labels={y_axis: y_axis}
        )
    
    return fig

def generate_heatmap(data, columns):
    """Generate a correlation heatmap"""
    corr_data = data[columns].corr()
    
    fig = px.imshow(
        corr_data,
        text_auto=True,
        aspect="auto",
        title="Correlation Heatmap",
        color_continuous_scale='RdBu_r',
        zmin=-1, zmax=1
    )
    
    return fig
