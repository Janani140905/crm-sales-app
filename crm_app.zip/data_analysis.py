import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go

def show_summary_statistics(data):
    """
    Display summary statistics for the dataset
    """
    st.subheader("Summary Statistics")
    
    # Get numeric and categorical columns
    numeric_cols = data.select_dtypes(include=['number']).columns
    categorical_cols = data.select_dtypes(exclude=['number']).columns
    
    # Display summary for numeric columns
    if len(numeric_cols) > 0:
        st.write("Numeric columns summary:")
        st.dataframe(data[numeric_cols].describe())
    
    # Display summary for categorical columns
    if len(categorical_cols) > 0:
        st.write("Categorical columns summary:")
        categorical_summary = pd.DataFrame({
            'Column': categorical_cols,
            'Unique Values': [data[col].nunique() for col in categorical_cols],
            'Top Value': [data[col].value_counts().index[0] if not data[col].value_counts().empty else None for col in categorical_cols],
            'Top Value Count': [data[col].value_counts().iloc[0] if not data[col].value_counts().empty else 0 for col in categorical_cols],
            'Null Count': [data[col].isna().sum() for col in categorical_cols]
        })
        st.dataframe(categorical_summary)
    
    # Check for missing values
    missing_data = data.isnull().sum()
    missing_data = missing_data[missing_data > 0].sort_values(ascending=False)
    
    if not missing_data.empty:
        st.subheader("Missing Values")
        missing_percent = (missing_data / len(data)) * 100
        missing_df = pd.DataFrame({
            'Column': missing_data.index,
            'Missing Values': missing_data.values,
            'Percentage': missing_percent.values
        })
        st.dataframe(missing_df)
        
        # Plot missing values
        fig = px.bar(
            missing_df, 
            x='Column', 
            y='Percentage',
            title='Percentage of Missing Values by Column',
            labels={'Percentage': 'Missing (%)'}
        )
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.write("No missing values found in the dataset.")

def show_distribution_analysis(data):
    """
    Display distribution analysis for dataset columns
    """
    st.subheader("Distribution Analysis")
    
    # Get numeric and categorical columns
    numeric_cols = data.select_dtypes(include=['number']).columns
    categorical_cols = data.select_dtypes(exclude=['number']).columns
    
    # Numeric column distribution
    if len(numeric_cols) > 0:
        st.write("### Numeric Column Distribution")
        selected_num_col = st.selectbox("Select a numeric column", numeric_cols)
        
        # Histogram and box plot
        col1, col2 = st.columns(2)
        
        with col1:
            fig_hist = px.histogram(
                data, 
                x=selected_num_col,
                nbins=30,
                title=f"Histogram of {selected_num_col}"
            )
            st.plotly_chart(fig_hist, use_container_width=True)
        
        with col2:
            fig_box = px.box(
                data,
                y=selected_num_col,
                title=f"Box Plot of {selected_num_col}"
            )
            st.plotly_chart(fig_box, use_container_width=True)
        
        # Show basic stats
        q1 = data[selected_num_col].quantile(0.25)
        q3 = data[selected_num_col].quantile(0.75)
        iqr = q3 - q1
        outliers = data[(data[selected_num_col] < (q1 - 1.5 * iqr)) | (data[selected_num_col] > (q3 + 1.5 * iqr))][selected_num_col]
        
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Mean", round(data[selected_num_col].mean(), 2))
        with col2:
            st.metric("Median", round(data[selected_num_col].median(), 2))
        with col3:
            st.metric("Std Dev", round(data[selected_num_col].std(), 2))
        with col4:
            st.metric("Outliers", len(outliers))
    
    # Categorical column distribution
    if len(categorical_cols) > 0:
        st.write("### Categorical Column Distribution")
        selected_cat_col = st.selectbox("Select a categorical column", categorical_cols)
        
        # Get value counts
        value_counts = data[selected_cat_col].value_counts().reset_index()
        value_counts.columns = [selected_cat_col, 'Count']
        
        # Limit to top 20 categories if there are too many
        if len(value_counts) > 20:
            st.info(f"Showing top 20 categories out of {len(value_counts)}")
            value_counts = value_counts.head(20)
        
        fig = px.bar(
            value_counts,
            x=selected_cat_col,
            y='Count',
            title=f"Distribution of {selected_cat_col}"
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Show percentage of total
        value_counts['Percentage'] = (value_counts['Count'] / value_counts['Count'].sum()) * 100
        st.dataframe(value_counts)

def show_correlation_analysis(data):
    """
    Display correlation analysis for numeric columns in the dataset
    """
    st.subheader("Correlation Analysis")
    
    # Get numeric columns only
    numeric_data = data.select_dtypes(include=['number'])
    
    if numeric_data.shape[1] < 2:
        st.warning("Need at least 2 numeric columns for correlation analysis.")
        return
    
    # Compute correlation matrix
    corr_matrix = numeric_data.corr()
    
    # Display correlation heatmap
    fig = px.imshow(
        corr_matrix, 
        text_auto=True, 
        aspect="auto",
        title="Correlation Matrix Heatmap",
        color_continuous_scale='RdBu_r',
        zmin=-1, zmax=1
    )
    st.plotly_chart(fig, use_container_width=True)
    
    # Option to view specific correlations
    st.subheader("Explore Specific Correlations")
    col1, col2 = st.columns(2)
    
    with col1:
        x_col = st.selectbox("Select X-axis variable", numeric_data.columns)
    with col2:
        y_col = st.selectbox("Select Y-axis variable", 
                           [col for col in numeric_data.columns if col != x_col],
                           index=min(1, len(numeric_data.columns)-1))
    
    # Create scatter plot
    fig = px.scatter(
        data,
        x=x_col,
        y=y_col,
        title=f"Correlation between {x_col} and {y_col}",
        trendline="ols",
    )
    st.plotly_chart(fig, use_container_width=True)
    
    # Display correlation coefficient
    corr_value = corr_matrix.loc[x_col, y_col]
    st.metric("Correlation Coefficient", round(corr_value, 3))
    
    # Describe the correlation strength
    if abs(corr_value) < 0.3:
        strength = "weak"
    elif abs(corr_value) < 0.7:
        strength = "moderate"
    else:
        strength = "strong"
    
    direction = "positive" if corr_value > 0 else "negative"
    
    st.write(f"This indicates a {strength} {direction} correlation between {x_col} and {y_col}.")

def show_group_by_analysis(data):
    """
    Display groupby analysis allowing user to aggregate data by categories
    """
    st.subheader("Group By Analysis")
    
    # Get categorical and numeric columns
    categorical_cols = data.select_dtypes(exclude=['number']).columns.tolist()
    numeric_cols = data.select_dtypes(include=['number']).columns.tolist()
    
    if not categorical_cols or not numeric_cols:
        st.warning("Need both categorical and numeric columns for group by analysis.")
        return
    
    # Let user select columns and aggregation functions
    groupby_col = st.selectbox("Select column to group by", categorical_cols)
    
    multi_metrics = st.multiselect(
        "Select metrics to calculate (numeric columns)",
        numeric_cols,
        default=[numeric_cols[0]] if numeric_cols else []
    )
    
    if not multi_metrics:
        st.warning("Please select at least one numeric column for aggregation.")
        return
        
    agg_functions = st.multiselect(
        "Select aggregation functions",
        ["Mean", "Median", "Sum", "Min", "Max", "Count", "Std"],
        default=["Mean"]
    )
    
    if not agg_functions:
        st.warning("Please select at least one aggregation function.")
        return
    
    # Create the aggregation dictionary
    agg_dict = {}
    function_map = {
        "Mean": "mean",
        "Median": "median",
        "Sum": "sum",
        "Min": "min",
        "Max": "max",
        "Count": "count",
        "Std": "std"
    }
    
    for metric in multi_metrics:
        agg_dict[metric] = [function_map[func] for func in agg_functions]
    
    # Perform group by operation
    try:
        grouped_data = data.groupby(groupby_col).agg(agg_dict)
        
        # Flatten the column multi-index
        grouped_data.columns = ['_'.join(col).strip() for col in grouped_data.columns.values]
        grouped_data = grouped_data.reset_index()
        
        # Display the grouped data
        st.dataframe(grouped_data)
        
        # Visualization
        st.subheader("Visualization")
        
        if len(grouped_data) > 20:
            st.info(f"Showing visualization for top 20 groups out of {len(grouped_data)}")
            grouped_data_viz = grouped_data.head(20)
        else:
            grouped_data_viz = grouped_data
            
        # Let user select which column to visualize
        viz_col = st.selectbox(
            "Select column to visualize",
            [col for col in grouped_data.columns if col != groupby_col]
        )
        
        # Create bar chart
        fig = px.bar(
            grouped_data_viz,
            x=groupby_col,
            y=viz_col,
            title=f"{viz_col} by {groupby_col}"
        )
        st.plotly_chart(fig, use_container_width=True)
        
    except Exception as e:
        st.error(f"Error in group by analysis: {e}")
